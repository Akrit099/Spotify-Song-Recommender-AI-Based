import streamlit as st
import pandas as pd

# Load clustered data
try:
    df = pd.read_csv("clustered_spotify_songs.csv")
except FileNotFoundError:
    st.error("❌ 'clustered_spotify_songs.csv' not found in this folder.")
    st.stop()

# Optional: Add cluster labels
cluster_labels = {
    0: "High Energy Mix",
    1: "Club / Dance",
    2: "Groovy & Chill",
    3: "Lyrical / Urban"
}
df['cluster_label'] = df['cluster'].map(cluster_labels)

# Define recommendation function
def recommend_similar_songs(song_name, df, n_recommendations=5):
    song = df[df['track_name'].str.lower() == song_name.lower()]
    if song.empty:
        return None
    cluster = song.iloc[0]['cluster']
    similar_songs = df[(df['cluster'] == cluster) & (df['track_name'].str.lower() != song_name.lower())]
    similar_songs = similar_songs.sort_values(by='track_popularity', ascending=False)
    return similar_songs[['track_name', 'track_artist', 'playlist_genre', 'track_popularity', 'cluster_label']].head(n_recommendations)

# Streamlit UI
st.set_page_config(page_title="Spotify Song Recommender", page_icon="🎵", layout="centered")
st.title("🎧 Spotify Song Recommender")
st.subheader("Find songs that match your vibe based on audio similarity")

# ✅ Clean dropdown list
song_list = sorted(df['track_name'].dropna().astype(str).unique())
song_input = st.selectbox("🎵 Select a song:", song_list)

# Number of recommendations
num_recs = st.slider("🔢 Number of recommendations:", 1, 20, 5)

# Recommend and show results
if song_input:
    results = recommend_similar_songs(song_input, df, num_recs)
    if results is not None and not results.empty:
        st.success(f"Top {num_recs} similar songs to: {song_input}")
        st.dataframe(results)

        # Download button
        csv = results.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="📥 Download as CSV",
            data=csv,
            file_name=f"{song_input}_recommendations.csv",
            mime='text/csv',
        )
    else:
        st.error("❌ Song not found or no similar songs available. Try a different one.")

# Footer
st.markdown("---")
st.markdown("🧠 Created by **Akrit** | Spotify Genre Grouping Internship Project 2025", unsafe_allow_html=True)
